







const https = require('https');
const start = new Date();



https.get('https://google.com', function(res) {
       let res_time = new Date() - start;
    // console.log('Request took:', res_time, 'ms');
  
    if(res_time <= 1000){
      console.log('good',res_time, 'ms');
    }
    else if(res_time > 1000 && res_time <= 5000){
      console.log('fine', res_time, 'ms');
    }
    else {
      setTimeout(myfunction, 0)    // waiting 5s 
      function myfunction(){
        console.log('bad');
      }
    }
});


