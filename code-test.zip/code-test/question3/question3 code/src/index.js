import React from 'react'
import { render } from 'react-dom'
import { ReactDOM} from 'react-dom'
import { Provider } from 'react-redux'
import { store } from './store'
import { Divider, TreeSelect } from 'antd';
import "antd/dist/antd.css";
import "./index.css";
import ListContainer from './containers/ListContainer'


const treeData = [
  {
    title: 'Category One',
    value: 'category1',
 
  },
  {
    title: 'Category Two',
    value: 'category2',
  },
  {
    title: 'Category Three',
    value: 'category3',
  },
  {
    title: 'Category Four',
    value: 'category4',
  },
  {
    title: 'Category Five',
    value: 'category5',
  },
];

class Demo extends React.Component {
  state = {
    value: undefined,
  };

  onChange = value => {
    console.log(value);
    alert(value);
    this.setState({ value });
  };

  render() {
    return (
      <TreeSelect
        style={{ width: '100%' }}
        value={this.state.value}
       
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        treeData={treeData}
        placeholder="Please select"
        treeDefaultExpandAll
        onChange={this.onChange}
      />
    );
  }
}


render(
  <div>
    <Provider store={store}>
        
    <ListContainer />
    
  </Provider>,
    
  <Demo />
  </div>,
  document.getElementById("root")
);



