import React, { Component } from "react";

class List extends Component {
  renderUsers(users) {
    if (users) {
      return users.map(({ categoryId, name }) => <li key={categoryId}>{name}</li>);
    }

    return null;
  }

  render() {
    return (
      <div>
        <div onClick={this.props.getUsers}>CLICK HERE to fetch data from API with redux</div>
        <ul>{this.renderUsers(this.props.users)}</ul>
      </div>
    );
  }
}

export default List;
