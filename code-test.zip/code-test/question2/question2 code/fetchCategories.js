const fetch = require('node-fetch');

fetch("http://localhost:8080/")
// .then(function(res){     
//     console.log(res.json());
// });

.then(response => response.json())
.then(data => console.log(data))