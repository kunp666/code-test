var express = require("express");
var app = express();
var cors = require('cors');
app.use(cors());
//Read JSON
const db = require('./categories.json');

//Main func for create tree from array
const createDataTree = (data) => {
  //Create each branch
  const dataBranch = Object.create(null);
  //Add children for each branch
  data.forEach(x => dataBranch[x.categoryId] = {
    ...x,
    children: []
  });
  //Sort data by categoryID
  data.sort((a, b) => a.categoryId.localeCompare(b.categoryId));
  //Create tree
  const dataTree = [];
  //Check its parent is root and it has parent, assign children in same parent
  data.forEach(x => {
    if (x.parent && x.parent != "root"){
      dataBranch[x.parent].children.push(dataBranch[x.categoryId]); 
    }       
    else{
      dataTree.push(dataBranch[x.categoryId]);
    } 
  });
  return dataTree;
};

//server endpoint res with datatree
app.get("/", (req, res) => {

  var dataset = createDataTree(db);
  res.json(dataset);
});

//Server listen
app.listen(8080, () => {
  console.log("Server running on port 8080");
});